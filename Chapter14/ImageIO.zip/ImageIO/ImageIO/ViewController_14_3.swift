//
//  ViewController_14_3.swift
//  ImageIO
//
//  Created by Youk Chansim on 2017. 4. 9..
//  Copyright © 2017년 Youk Chansim. All rights reserved.
//

import UIKit

class CollectionViewCell_14_3: UICollectionViewCell {
    @IBOutlet weak var imageView: UIImageView!
}

class ViewController_14_3: UIViewController {
    @IBOutlet weak var collectionView: UICollectionView!
    
    var imagePaths: [String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        imagePaths = Bundle.main.paths(forResourcesOfType: "png", inDirectory: "Vacation Photos")
    }
}

extension ViewController_14_3: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return imagePaths.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CollectionViewCell_14_3", for: indexPath) as? CollectionViewCell_14_3 else {
            return UICollectionViewCell()
        }
        
        let imageTag = 99
        
        cell.imageView.tag = imageTag
        cell.tag = indexPath.row
        
        DispatchQueue.global().async {
            let index = indexPath.row
            let imagePath = self.imagePaths[index]
            var image = UIImage(contentsOfFile: imagePath)
            
            UIGraphicsBeginImageContextWithOptions(cell.imageView.bounds.size, true, 0)
            image?.draw(in: cell.imageView.bounds)
            image = UIGraphicsGetImageFromCurrentImageContext()
            UIGraphicsEndImageContext()
            
            DispatchQueue.main.async {
                if index == cell.tag {
                    cell.imageView.image = image
                }
            }
        }
        
        return cell
    }
}
