//
//  ViewController_14_6.swift
//  ImageIO
//
//  Created by Youk Chansim on 2017. 4. 12..
//  Copyright © 2017년 Youk Chansim. All rights reserved.
//

import UIKit

class TableViewCell_14_6: UITableViewCell {
    @IBOutlet weak var sizeLabel: UILabel!
    @IBOutlet weak var timeLabel: UILabel!
}

class ViewController_14_6: UIViewController {
    @IBOutlet weak var tableView: UITableView!

    let imageFolder = "Coast Photos"
    
    let items = [
        "2048x1536",
        "1024x768",
        "512x384",
        "256x192",
        "128x96",
        "64x48",
        "32x24",
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.dataSource = self
    }
}

extension ViewController_14_6 {
    func loadImageForOneSec(path: String) -> CFTimeInterval {
        UIGraphicsBeginImageContext(CGSize(width: 1, height: 1))
        
        var imagesLoaded = 0
        var endTime: CFTimeInterval = 0
        let startTime = CFAbsoluteTimeGetCurrent()
        
        while endTime - startTime < 1 {
            let image = UIImage(contentsOfFile: path)
            
            image?.draw(at: CGPoint.zero)
            
            imagesLoaded += 1
            endTime = CFAbsoluteTimeGetCurrent()
        }
        
        UIGraphicsEndImageContext()
        
        return (endTime - startTime) / CFTimeInterval(imagesLoaded)
    }
    
    func loadImageAtIndex(index: Int) {
        DispatchQueue.global().async {
            let fileName = self.items[index]
            let pngPath = Bundle.main.path(forResource: fileName, ofType: "png", inDirectory: self.imageFolder) ?? ""
            let jpgPath = Bundle.main.path(forResource: fileName, ofType: "jpg", inDirectory: self.imageFolder) ?? ""
            
            let pngTime = self.loadImageForOneSec(path: pngPath) * 1000
            let jpgTime = self.loadImageForOneSec(path: jpgPath) * 1000
            
            DispatchQueue.main.async {
                let indexPath = IndexPath(row: index, section: 0)
                if let cell = self.tableView.cellForRow(at: indexPath) as? TableViewCell_14_6 {
                    cell.timeLabel.text = String(format: "PNG: %03ims, JPG: %03ims", pngTime, jpgTime)
                }
            }
        }
    }
}

extension ViewController_14_6: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell_14_6", for: indexPath) as? TableViewCell_14_6 else {
            return UITableViewCell()
        }
        
        cell.sizeLabel.text = "\(items[indexPath.row])"
        cell.timeLabel.text = "Loading..."
        
        loadImageAtIndex(index: indexPath.row)
        
        return cell
    }
}
