//
//  ViewController_14_4.swift
//  ImageIO
//
//  Created by Youk Chansim on 2017. 4. 9..
//  Copyright © 2017년 Youk Chansim. All rights reserved.
//

import UIKit

class CollectionViewCell_14_4: UICollectionViewCell {
    @IBOutlet weak var imageView: UIImageView!
}

class ViewController_14_4: UIViewController {
    @IBOutlet weak var collectionView: UICollectionView!
    
    var imagePaths: [String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        imagePaths = Bundle.main.paths(forResourcesOfType: "png", inDirectory: "Vacation Photos")
    }
}

extension ViewController_14_4: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return imagePaths.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CollectionViewCell_14_4", for: indexPath) as? CollectionViewCell_14_4 else {
            return UICollectionViewCell()
        }
        var tileLayer = cell.contentView.layer.sublayers?.last
        if tileLayer == nil {
            tileLayer = CATiledLayer()
            tileLayer?.frame = cell.bounds
            tileLayer?.contentsScale = UIScreen.main.scale
            tileLayer?.setValue(indexPath.row, forKey: "index")
            tileLayer?.delegate = self
            cell.contentView.layer.addSublayer(tileLayer ?? CATiledLayer())
        }
        
        tileLayer?.contents = nil
        tileLayer?.setValue(indexPath.row, forKey: "index")
        tileLayer?.setNeedsDisplay()
        
        return cell
    }
}

extension ViewController_14_4: CALayerDelegate {
    func draw(_ layer: CALayer, in ctx: CGContext) {
        let index = layer.value(forKey: "index") as? Int ?? 0
        let imagePath = imagePaths[index]
        let tileImage = UIImage(contentsOfFile: imagePath) ?? UIImage()
        
        let aspectRatio = tileImage.size.height / tileImage.size.width
        var imageRect = CGRect.zero
        
        imageRect.size.width = layer.bounds.size.width
        imageRect.size.height = layer.bounds.size.height * aspectRatio
        imageRect.origin.y = (layer.bounds.size.height - imageRect.size.height) / 2
        
        UIGraphicsPushContext(ctx)
        tileImage.draw(in: imageRect)
        UIGraphicsPopContext()
    }
}
