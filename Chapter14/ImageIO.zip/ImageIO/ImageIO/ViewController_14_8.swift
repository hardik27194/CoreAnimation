//
//  ViewController_14_8.swift
//  ImageIO
//
//  Created by Youk Chansim on 2017. 4. 12..
//  Copyright © 2017년 Youk Chansim. All rights reserved.
//

import UIKit
import QuartzCore
import GLKit

class ViewController_14_8: UIViewController {

    @IBOutlet weak var glView: UIView!
    var glContext: EAGLContext!
    var glLayer: CAEAGLLayer!
    var frameBuffer: UnsafeMutablePointer<GLuint>! = UnsafeMutablePointer<GLuint>.allocate(capacity: 1)
    var colorRenderBuffer: UnsafeMutablePointer<GLuint>! = UnsafeMutablePointer<GLuint>.allocate(capacity: 1)
    var framebufferWidth: UnsafeMutablePointer<GLint>! = UnsafeMutablePointer<GLint>.allocate(capacity: 1)
    var framebufferHeight: UnsafeMutablePointer<GLint>! = UnsafeMutablePointer<GLint>.allocate(capacity: 1)
    var effect: GLKBaseEffect!
    var textureInfo: GLKTextureInfo!
    
    func setUpBuffers() {
        glGenFramebuffers(1, &frameBuffer.pointee)
        glBindFramebuffer(GLenum(GL_FRAMEBUFFER), frameBuffer.pointee)

        glGenRenderbuffers(1, &colorRenderBuffer.pointee)
        glBindRenderbuffer(GLenum(GL_RENDERBUFFER), colorRenderBuffer.pointee)
        glFramebufferRenderbuffer(GLenum(GL_FRAMEBUFFER), GLenum(GL_COLOR_ATTACHMENT0), GLenum(GL_RENDERBUFFER), colorRenderBuffer.pointee)
        
        glContext.renderbufferStorage(Int(GL_RENDERBUFFER), from: glLayer)
        
        glGetRenderbufferParameteriv(GLenum(GL_RENDERBUFFER), GLenum(GL_RENDERBUFFER_WIDTH), &framebufferWidth.pointee)
        glGetRenderbufferParameteriv(GLenum(GL_RENDERBUFFER), GLenum(GL_RENDERBUFFER_HEIGHT), &framebufferHeight.pointee)
        
        if glCheckFramebufferStatus(GLenum(GL_FRAMEBUFFER)) != GLenum(GL_FRAMEBUFFER_COMPLETE) {
            print("Failed to make complete framebuffer object: \(glCheckFramebufferStatus(GLenum(GL_FRAMEBUFFER)))")
        }
    }
    
    func tearDownBuffers() {
        if frameBuffer.pointee == 0 {
            glDeleteFramebuffers(1, &frameBuffer.pointee)
            frameBuffer.pointee = 0
        }
        
        if colorRenderBuffer.pointee == 0 {
            glDeleteFramebuffers(1, &colorRenderBuffer.pointee)
            colorRenderBuffer.pointee = 0
        }
    }
    
    func drawFrame() {
        glBindFramebuffer(GLenum(GL_FRAMEBUFFER), frameBuffer.pointee)
        glViewport(0, 0, framebufferWidth.pointee, framebufferHeight.pointee)
        
        effect.prepareToDraw()
        
        glClear(GLbitfield(GL_COLOR_BUFFER_BIT))
        glClearColor(0, 0, 0, 0)
        
        let vertices: [GLfloat] = [
            -1.0, -1.0,
            -1.0, 1.0,
            1.0, 1.0,
            1.0, -1.0,
            ]
        
        let textCoords: [GLfloat] = [
            0, 1,
            0, 0,
            1, 0,
            1, 1,
        ]
        
        glEnableVertexAttribArray(GLuint(GLKVertexAttrib.position.rawValue))
        glEnableVertexAttribArray(GLuint(GLKVertexAttrib.texCoord0.rawValue))
        glVertexAttribPointer(GLuint(GLKVertexAttrib.position.rawValue), 2, GLenum(GL_FLOAT), GLboolean(GL_FALSE), 0, vertices)
        glVertexAttribPointer(GLuint(GLKVertexAttrib.texCoord0.rawValue), 2, GLenum(GL_FLOAT), GLboolean(GL_FALSE), 0, textCoords)
        glDrawArrays(GLenum(GL_TRIANGLE_FAN), 0, 4)
        
        glBindRenderbuffer(GLenum(GL_RENDERBUFFER), colorRenderBuffer.pointee)
        glContext.presentRenderbuffer(Int(GL_RENDERBUFFER))
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        glContext = EAGLContext(api: .openGLES2)
        EAGLContext.setCurrent(glContext)
        
        glLayer = CAEAGLLayer(layer: glView.layer)
        glLayer.frame = glView.bounds
        glLayer.isOpaque = false
        glView.layer.addSublayer(glLayer)
        
        glLayer.drawableProperties = [
            kEAGLDrawablePropertyRetainedBacking: NSNumber(value: false),
            kEAGLDrawablePropertyColorFormat: kEAGLColorFormatRGBA8
        ]
        
        glActiveTexture(GLenum(GL_TEXTURE0))
        
        let imageFile = Bundle.main.path(forResource: "Snowman", ofType: "pvr") ?? ""
        textureInfo = try? GLKTextureLoader.texture(withContentsOfFile: imageFile, options: nil)
        
        let texture = GLKEffectPropertyTexture()
        texture.enabled = GLboolean(GL_TRUE)
        texture.envMode = .decal
        texture.name = textureInfo.name
        
        effect = GLKBaseEffect()
        effect.texture2d0.name = texture.name
        
        setUpBuffers()
        drawFrame()
    }
    
    deinit {
        tearDownBuffers()
        EAGLContext.setCurrent(nil)
    }
}
