//
//  ViewController_14_5.swift
//  ImageIO
//
//  Created by Youk Chansim on 2017. 4. 9..
//  Copyright © 2017년 Youk Chansim. All rights reserved.
//

import UIKit

class CollectionViewCell_14_5: UICollectionViewCell {
    @IBOutlet weak var imageView: UIImageView!
}

class ViewController_14_5: UIViewController {
    @IBOutlet weak var collectionView: UICollectionView!
    
    var imagePaths: [String] = []
    var cache = NSCache<AnyObject, UIImage>()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        imagePaths = Bundle.main.paths(forResourcesOfType: "png", inDirectory: "Vacation Photos")
    }
}

extension ViewController_14_5 {
    @discardableResult
    func loadImageAtIndex(index: Int) -> UIImage? {
        if let image = cache.object(forKey: index as AnyObject) {
            return image
        }
        
        cache.removeObject(forKey: index as AnyObject)
        
        DispatchQueue.global().async {
            let imagePath = self.imagePaths[index]
            var image = UIImage(contentsOfFile: imagePath) ?? UIImage()
            
            UIGraphicsBeginImageContextWithOptions(image.size, true, 0)
            image.draw(at: CGPoint.zero)
            image = UIGraphicsGetImageFromCurrentImageContext()!
            UIGraphicsEndImageContext()
            
            DispatchQueue.main.async {
                self.cache.setObject(image, forKey: index as AnyObject)
                let indexPath = IndexPath(item: index, section: 0)
                if let cell = self.collectionView.cellForItem(at: indexPath) as? CollectionViewCell_14_5 {
                    cell.imageView.image = image
                }
            }
        }
        
        return nil
    }
}

extension ViewController_14_5: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return imagePaths.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CollectionViewCell_14_5", for: indexPath) as? CollectionViewCell_14_5 else {
            return UICollectionViewCell()
        }
        
        cell.imageView.image = loadImageAtIndex(index: indexPath.item)
        if indexPath.item < imagePaths.count - 1 {
            loadImageAtIndex(index: indexPath.item + 1)
        }
        
        if indexPath.item > 0 {
            loadImageAtIndex(index: indexPath.item - 1)
        }
        
        return cell
    }
}
