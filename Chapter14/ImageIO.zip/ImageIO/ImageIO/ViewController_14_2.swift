//
//  ViewController_14_2.swift
//  ImageIO
//
//  Created by Youk Chansim on 2017. 4. 9..
//  Copyright © 2017년 Youk Chansim. All rights reserved.
//

import UIKit

class CollectionViewCell_14_2: UICollectionViewCell {
    @IBOutlet weak var imageView: UIImageView!
}

class ViewController_14_2: UIViewController {
    @IBOutlet weak var collectionView: UICollectionView!
    
    var imagePaths: [String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        imagePaths = Bundle.main.paths(forResourcesOfType: "png", inDirectory: "Vacation Photos")
    }
}

extension ViewController_14_2: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return imagePaths.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CollectionViewCell_14_2", for: indexPath) as? CollectionViewCell_14_2 else {
            return UICollectionViewCell()
        }
        
        let imageTag = 99
        
        cell.imageView.tag = imageTag
        cell.tag = indexPath.row
        
        DispatchQueue.global().async {
            let index = indexPath.row
            let imagePath = self.imagePaths[index]
            let image = UIImage(contentsOfFile: imagePath)
            
            DispatchQueue.main.async {
                if index == cell.tag {
                    cell.imageView.image = image
                }
            }
        }
        
        return cell
    }
}
