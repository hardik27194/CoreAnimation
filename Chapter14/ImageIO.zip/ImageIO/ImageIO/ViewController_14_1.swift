//
//  ViewController.swift
//  ImageIO
//
//  Created by Youk Chansim on 2017. 4. 6..
//  Copyright © 2017년 Youk Chansim. All rights reserved.
//

import UIKit

class CollectionViewCell_14_1: UICollectionViewCell {
    @IBOutlet weak var imageView: UIImageView!
}

class ViewController_14_1: UIViewController {
    @IBOutlet weak var collectionView: UICollectionView!
    
    var imagePaths: [String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        imagePaths = Bundle.main.paths(forResourcesOfType: "png", inDirectory: "Vacation Photos")
    }
}

extension ViewController_14_1: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return imagePaths.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CollectionViewCell_14_1", for: indexPath) as? CollectionViewCell_14_1 else {
            return UICollectionViewCell()
        }
        
        let imagePath = imagePaths[indexPath.row]
        cell.imageView.image = UIImage(contentsOfFile: imagePath)
        
        return cell
    }
}
