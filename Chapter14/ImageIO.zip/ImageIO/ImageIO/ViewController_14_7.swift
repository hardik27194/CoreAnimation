//
//  ViewController_14_7.swift
//  ImageIO
//
//  Created by Youk Chansim on 2017. 4. 12..
//  Copyright © 2017년 Youk Chansim. All rights reserved.
//

import UIKit

class ViewController_14_7: UIViewController {
    @IBOutlet weak var imageView: UIImageView!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let image = UIImage(named: "Snowman")
        let mask = UIImage(named: "SnowmanMask")
        
        let graySpace = CGColorSpaceCreateDeviceGray()
        let maskRef = mask?.cgImage?.copy(colorSpace: graySpace)
        
        //combine images
        let resultRef = image?.cgImage?.masking(maskRef!)
        let result = UIImage(cgImage: resultRef!)
        
        imageView.image = result
    }
}
